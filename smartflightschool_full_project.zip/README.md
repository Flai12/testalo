# SmartFlightSchool Chat Dash — Multi-tenant Starter

## Features
- Multi-tenant chat pages at `/chat/[tenantId]`
- Backend `/api/chat` that proxies to Botpress Cloud (tenant-specific tokens)
- Admin UI to create tenants (simple file-based store)
- Example embed widget (iframe)

## Quick start (non-technical)
1. Install Node.js (v18+ recommended).
2. Unzip the project.
3. In the project folder run `npm install`.
4. Run locally with `npm run dev`.
5. Open `http://localhost:3000` and visit `/admin` to create tenants or edit `tenants.json`.
6. Deploy to Vercel by connecting the project repo.

## Notes
- Replace `tenants.json` with a database (Supabase) for production and move secrets to environment variables.
- If you need, I can deploy this project for you and secure the admin panel.
