export default function EmbedWidget({ tenantId }) {
  const url = `/chat/${tenantId}`
  return (
    <div className="fixed bottom-6 right-6">
      <iframe src={url} style={{ width: 360, height: 560, borderRadius: 12, border: '1px solid rgba(0,0,0,0.06)' }} />
    </div>
  )
}
