import Link from 'next/link'
export default function Index() {
  return (
    <div className="p-8">
      <h1 className="text-3xl font-bold">SmartFlightSchool — Chat Wrapper (Multi-tenant)</h1>
      <p className="mt-4">Open a tenant chat: <Link href="/chat/demo-school"><a className="text-sky-600">/chat/demo-school</a></Link></p>
      <p className="mt-4">Admin dashboard: <Link href="/admin"><a className="text-sky-600">/admin</a></Link></p>
    </div>
  )
}
