import { useState, useEffect, useRef } from 'react'
import { useRouter } from 'next/router'

export default function TenantChat() {
  const router = useRouter()
  const { tenantId } = router.query
  const [tenant, setTenant] = useState(null)
  const [input, setInput] = useState('')
  const [messages, setMessages] = useState([])
  const convRef = useRef(null)

  useEffect(() => {
    if (!tenantId) return
    fetch(`/api/tenants/${tenantId}`).then(r => r.json()).then(setTenant).catch(()=>setTenant(null))
  }, [tenantId])

  async function send() {
    if (!input.trim()) return
    const userMsg = { id: Date.now(), role: 'user', text: input }
    setMessages(m => [...m, userMsg])
    setInput('')
    const res = await fetch('/api/chat', { method: 'POST', headers: {'Content-Type':'application/json'}, body: JSON.stringify({ tenantId, message: userMsg.text }) })
    const data = await res.json()
    const botText = (data?.text) || (Array.isArray(data) && data[0]?.text) || JSON.stringify(data)
    setMessages(m => [...m, { id: Date.now()+1, role: 'bot', text: botText }])
  }

  if (!tenant) return <div className="p-8">Loading tenant...</div>

  return (
    <div className="min-h-screen flex flex-col" style={{ background: tenant.theme.bg, color: tenant.theme.text }}>
      <header className="p-4 shadow-sm flex items-center gap-3">
        <div style={{ width: 12, height: 12, background: tenant.theme.accent, borderRadius: 4 }} />
        <h1 className="text-xl font-semibold">{tenant.name} — Chat</h1>
      </header>

      <main className="flex-1 p-6 overflow-y-auto">
        <div className="max-w-2xl mx-auto">
          {messages.map(m => (
            <div key={m.id} className={m.role === 'user' ? 'text-right my-2' : 'text-left my-2'}>
              <div className={"inline-block p-3 rounded-lg " + (m.role === 'user' ? 'bg-slate-100' : 'bg-white')}>{m.text}</div>
            </div>
          ))}
        </div>
      </main>

      <footer className="p-4 border-t">
        <div className="max-w-2xl mx-auto flex gap-3">
          <input value={input} onChange={e=>setInput(e.target.value)} className="flex-1 p-3 rounded border" placeholder="Ask about bookings, pricing, or training" />
          <button onClick={send} className="px-4 py-2 rounded bg-slate-800 text-white">Send</button>
        </div>
      </footer>
    </div>
  )
}
