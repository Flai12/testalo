import { getTenant, upsertTenant } from '../../../lib/tenants'
export default function handler(req, res) {
  const { id } = req.query
  if (req.method === 'GET') {
    const t = getTenant(id)
    if (!t) return res.status(404).json({ error: 'not found' })
    return res.json(t)
  }
  if (req.method === 'POST') {
    const payload = req.body
    const updated = upsertTenant(id, payload)
    return res.json(updated)
  }
  res.setHeader('Allow', 'GET,POST')
  res.status(405).end()
}
