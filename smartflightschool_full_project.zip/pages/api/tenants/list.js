import { readTenants } from '../../../lib/tenants'
export default function handler(req, res) { res.json(readTenants()) }
