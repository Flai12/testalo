import fetch from 'node-fetch'
import { getTenant } from '../../lib/tenants'

export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).end()
  const { tenantId, message, conversationId } = req.body
  if (!tenantId || !message) return res.status(400).json({ error: 'tenantId and message required' })

  const tenant = getTenant(tenantId)
  if (!tenant) return res.status(404).json({ error: 'tenant not found' })

  const token = tenant.botpress?.token || process.env.BOTPRESS_DEFAULT_TOKEN
  if (!token) return res.status(500).json({ error: 'botpress token not configured for tenant' })

  const payload = {
    agentId: tenant.botpress.agentId,
    text: message,
    conversationId: conversationId || undefined
  }

  try {
    const r = await fetch('https://api.botpress.cloud/v1/chat/send', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
      body: JSON.stringify(payload)
    })

    if (!r.ok) {
      const text = await r.text()
      return res.status(r.status).json({ error: text })
    }

    const json = await r.json()
    return res.json(json)
  } catch (err) {
    console.error(err)
    return res.status(500).json({ error: 'upstream request failed' })
  }
}
