import { useEffect, useState } from 'react'
import { nanoid } from 'nanoid'
export default function Admin() {
  const [tenants, setTenants] = useState({})
  const [id, setId] = useState('')
  const [name, setName] = useState('')

  async function loadAll() {
    const r = await fetch('/api/tenants/list')
    const json = await r.json()
    setTenants(json)
  }

  async function create() {
    const tid = id || nanoid(8)
    await fetch(`/api/tenants/${tid}`, { method: 'POST', headers: {'Content-Type':'application/json'}, body: JSON.stringify({ id: tid, name, botpress: { agentId: '', token: '' }, theme: { accent: '#0ea5a4', bg: '#ffffff', text: '#0f172a' } }) })
    loadAll()
    setId(''); setName('')
  }

  useEffect(()=>{ loadAll() }, [])

  return (
    <div className="p-8">
      <h2 className="text-2xl font-semibold">Admin — Tenants</h2>
      <div className="mt-6 grid grid-cols-2 gap-6">
        <div>
          <h3 className="font-medium">Create Tenant</h3>
          <input className="border p-2 w-full mt-2" placeholder="id (optional)" value={id} onChange={e=>setId(e.target.value)} />
          <input className="border p-2 w-full mt-2" placeholder="name" value={name} onChange={e=>setName(e.target.value)} />
          <button className="mt-2 px-4 py-2 bg-slate-800 text-white rounded" onClick={create}>Create</button>
        </div>

        <div>
          <h3 className="font-medium">Existing Tenants</h3>
          <pre className="p-3 bg-slate-100 max-h-96 overflow-auto">{JSON.stringify(tenants, null, 2)}</pre>
        </div>
      </div>
    </div>
  )
}
